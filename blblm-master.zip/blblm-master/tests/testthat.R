library(testthat)
library(blblm)

test_check("blblm")
